# Proxima React Native UI

A starter Expo / React Native project based on the supplied Proxima wallet screen.

## Run it
1. Install Node.js on your computer.
2. In this folder, run `npm install`.
3. Run `npx expo start`.
4. Scan the QR code with Expo Go, or run on an Android emulator.

## Important
This is a front-end UI prototype only. The balance, card details, and transaction history are sample data. It is not connected to a bank, payment provider, authentication system, or backend, and it cannot send or receive real money.
