import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  SafeAreaView,
} from 'react-native';

const transactions = [
  { name: 'Netflix', time: 'Today • 2:30 PM', amount: '-Rs. 1,599', type: 'expense', icon: 'N' },
  { name: 'Salary Deposit', time: 'Yesterday • 9:00 AM', amount: '+Rs. 25,000', type: 'income', icon: '↓' },
  { name: 'Grocery Store', time: 'Yesterday • 6:15 PM', amount: '-Rs. 2,450', type: 'expense', icon: 'G' },
  { name: 'Online Transfer', time: 'Oct 15 • 11:20 AM', amount: '+Rs. 5,000', type: 'income', icon: '↗' },
];

function TransactionItem({ name, time, amount, type, icon }) {
  return (
    <View style={styles.transactionItem}>
      <View style={[styles.transactionIcon, type === 'income' && styles.incomeIcon]}>
        <Text style={styles.transactionIconText}>{icon}</Text>
      </View>
      <View style={styles.transactionDetails}>
        <Text style={styles.transactionName}>{name}</Text>
        <Text style={styles.transactionTime}>{time}</Text>
      </View>
      <Text style={[styles.transactionAmount, type === 'income' && styles.incomeAmount]}>
        {amount}
      </Text>
    </View>
  );
}

export default function ProximaApp() {
  const actions = [
    { label: 'Send Money', icon: '↗' },
    { label: 'Bill Pay', icon: '▤' },
    { label: 'Top Up', icon: '+' },
    { label: 'Request', icon: '↓' },
  ];

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#071B18" />
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Good evening, Alex</Text>
            <Text style={styles.headerSubtitle}>Welcome back to your wallet</Text>
          </View>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>A</Text>
          </View>
        </View>

        <Text style={styles.logo}>✦ Proxima</Text>

        <View style={styles.balanceCard}>
          <View style={styles.balanceTopRow}>
            <Text style={styles.balanceLabel}>Total Balance</Text>
            <Text style={styles.balanceDots}>•••</Text>
          </View>
          <Text style={styles.balanceAmount}>Rs. 12,540.32</Text>
          <Text style={styles.balanceGrowth}>↗  +Rs. 1,240.50 this month</Text>
          <View style={styles.cardDivider} />
          <View style={styles.cardFooter}>
            <View>
              <Text style={styles.cardCaption}>CARD NUMBER</Text>
              <Text style={styles.cardText}>•••• 4528  Primary Card</Text>
            </View>
            <View>
              <Text style={styles.cardCaption}>EXPIRES</Text>
              <Text style={styles.cardText}>12/28</Text>
            </View>
          </View>
          <View style={styles.cardDecorOne} />
          <View style={styles.cardDecorTwo} />
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <Text style={styles.sectionHint}>Manage money</Text>
        </View>
        <View style={styles.actionsRow}>
          {actions.map((item) => (
            <TouchableOpacity
              key={item.label}
              style={styles.actionBtn}
              activeOpacity={0.75}
              onPress={() => {}}
            >
              <View style={styles.actionCircle}>
                <Text style={styles.actionIcon}>{item.icon}</Text>
              </View>
              <Text style={styles.actionText}>{item.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.historyHeader}>
          <Text style={styles.sectionTitle}>Transaction History</Text>
          <TouchableOpacity activeOpacity={0.7} onPress={() => {}}>
            <Text style={styles.seeAll}>See all</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.transactionsCard}>
          {transactions.map((item, index) => (
            <View key={`${item.name}-${index}`}>
              <TransactionItem {...item} />
              {index < transactions.length - 1 && <View style={styles.transactionDivider} />}
            </View>
          ))}
        </View>

        <View style={styles.notice}>
          <Text style={styles.noticeTitle}>Your money, your future.</Text>
          <Text style={styles.noticeText}>
            This is a UI demo. Balance and transactions are sample data, not a real bank account.
          </Text>
        </View>
        <View style={{ height: 28 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#071B18' },
  container: { flex: 1, backgroundColor: '#F5F8F7' },
  header: {
    backgroundColor: '#071B18',
    paddingHorizontal: 22,
    paddingTop: 18,
    paddingBottom: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  greeting: { color: '#FFFFFF', fontSize: 20, fontWeight: '700' },
  headerSubtitle: { color: '#A9C0B9', fontSize: 12, marginTop: 5 },
  avatar: {
    width: 43, height: 43, borderRadius: 22, backgroundColor: '#D7B66D',
    alignItems: 'center', justifyContent: 'center',
  },
  avatarText: { color: '#102A24', fontSize: 18, fontWeight: '800' },
  logo: {
    backgroundColor: '#071B18', color: '#E7CB85', fontSize: 23,
    fontWeight: '800', paddingHorizontal: 22, paddingBottom: 22,
    letterSpacing: 0.5,
  },
  balanceCard: {
    marginHorizontal: 18, marginTop: 2, marginBottom: 27, padding: 22,
    borderRadius: 24, backgroundColor: '#126B52', overflow: 'hidden',
    minHeight: 208, elevation: 5,
  },
  balanceTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  balanceLabel: { color: '#D4EEE4', fontSize: 14, fontWeight: '500' },
  balanceDots: { color: '#FFFFFF', fontSize: 18, letterSpacing: 2 },
  balanceAmount: { color: '#FFFFFF', fontSize: 31, fontWeight: '800', marginTop: 11 },
  balanceGrowth: { color: '#B9F2D7', fontSize: 12, marginTop: 8, fontWeight: '600' },
  cardDivider: { height: 1, backgroundColor: 'rgba(255,255,255,0.22)', marginTop: 22, marginBottom: 13 },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', paddingRight: 24 },
  cardCaption: { color: '#B9DCCF', fontSize: 9, letterSpacing: 1.1, marginBottom: 5 },
  cardText: { color: '#FFFFFF', fontSize: 11, fontWeight: '600' },
  cardDecorOne: {
    position: 'absolute', width: 155, height: 155, borderRadius: 78,
    borderWidth: 25, borderColor: 'rgba(255,255,255,0.05)', right: -65, top: -65,
  },
  cardDecorTwo: {
    position: 'absolute', width: 115, height: 115, borderRadius: 58,
    borderWidth: 20, borderColor: 'rgba(255,255,255,0.05)', right: -30, bottom: -72,
  },
  sectionHeader: {
    marginHorizontal: 22, marginBottom: 16, flexDirection: 'row',
    justifyContent: 'space-between', alignItems: 'center',
  },
  sectionTitle: { color: '#142B25', fontSize: 17, fontWeight: '800' },
  sectionHint: { color: '#879790', fontSize: 11 },
  actionsRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingHorizontal: 17, marginBottom: 29,
  },
  actionBtn: { alignItems: 'center', width: '24%' },
  actionCircle: {
    width: 55, height: 55, borderRadius: 19, backgroundColor: '#FFFFFF',
    alignItems: 'center', justifyContent: 'center', marginBottom: 9,
    borderWidth: 1, borderColor: '#E5ECE8',
  },
  actionIcon: { color: '#126B52', fontSize: 24, fontWeight: '700' },
  actionText: { color: '#42554D', fontSize: 10, fontWeight: '600', textAlign: 'center' },
  historyHeader: {
    marginHorizontal: 22, marginBottom: 14, flexDirection: 'row',
    alignItems: 'center', justifyContent: 'space-between',
  },
  seeAll: { color: '#16765B', fontSize: 12, fontWeight: '700' },
  transactionsCard: {
    marginHorizontal: 18, backgroundColor: '#FFFFFF', borderRadius: 20,
    paddingHorizontal: 15, borderWidth: 1, borderColor: '#EAF0ED',
  },
  transactionItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 15 },
  transactionIcon: {
    width: 43, height: 43, borderRadius: 15, backgroundColor: '#FBE9E6',
    alignItems: 'center', justifyContent: 'center', marginRight: 12,
  },
  incomeIcon: { backgroundColor: '#E1F5EB' },
  transactionIconText: { color: '#315B4C', fontSize: 17, fontWeight: '800' },
  transactionDetails: { flex: 1 },
  transactionName: { color: '#1C3029', fontSize: 13, fontWeight: '700' },
  transactionTime: { color: '#91A099', fontSize: 10, marginTop: 5 },
  transactionAmount: { color: '#C04F45', fontSize: 12, fontWeight: '800' },
  incomeAmount: { color: '#16815D' },
  transactionDivider: { height: 1, backgroundColor: '#EEF2F0', marginLeft: 55 },
  notice: {
    marginHorizontal: 18, marginTop: 22, padding: 17,
    backgroundColor: '#E8F2ED', borderRadius: 17,
  },
  noticeTitle: { color: '#14523F', fontSize: 13, fontWeight: '800', marginBottom: 5 },
  noticeText: { color: '#60756C', fontSize: 11, lineHeight: 17 },
});
