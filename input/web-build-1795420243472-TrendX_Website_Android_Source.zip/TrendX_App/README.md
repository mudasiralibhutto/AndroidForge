# TrendX — short-video app starter

A responsive short-video **website/PWA** starter with a TikTok-inspired layout.

## Included
- Full-screen vertical video feed with For You, Following and Trending tabs
- Local video selection and caption publishing
- Like, comment, follow and share interactions
- Discover search and hashtag chips
- Editable local profile
- PWA manifest and service worker
- Android wrapper setup using Capacitor

## Run the website
You can open `index.html` for a quick preview. For PWA installation and service-worker support, serve this folder over HTTPS or localhost.

Example:
```bash
python -m http.server 8080
```
Then visit `http://localhost:8080`.

## Android APK build
This source is prepared for a Capacitor Android wrapper. You need Node.js, Android Studio and Android SDK installed.

```bash
npm install
npm run android:add
npm run android:open
```
In Android Studio, build a debug APK from **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

To make the wrapper work, run `npm install` and `npx cap add android` once. The `android` folder is generated locally by Capacitor.

## Important limitations
This is a front-end prototype. Videos, likes, comments and profile changes are local to the current browser/device. The sample feed uses public demonstration video URLs. There is no real account login, cloud video upload, cross-device sync, live messaging, moderation, or admin backend yet. Those require a secure backend (for example Firebase or Supabase), storage rules, authentication and moderation tools.

Never put private API keys or admin credentials in front-end JavaScript.
