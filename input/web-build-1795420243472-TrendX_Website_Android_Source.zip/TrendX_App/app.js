/* TrendX front-end prototype.
   This version stores demo content on this device only.
   A real multi-user network needs a secure backend and authentication. */
(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const storageKey = "trendx.posts.v1";
  const profileKey = "trendx.profile.v1";
  const starterPosts = [
    {
      id: "welcome-1",
      username: "trendx_official",
      displayName: "TrendX Official",
      caption: "Welcome to TrendX! Watch, create and share your moments. ✨ #TrendX #Pakistan",
      sound: "Original sound — TrendX",
      src: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
      likes: 12800,
      comments: [{ user: "ali_creator", text: "Welcome! 🔥" }],
      liked: false,
      following: true,
      local: false
    },
    {
      id: "welcome-2",
      username: "nature_daily",
      displayName: "Nature Daily",
      caption: "A little reminder to enjoy the beautiful things around you. 🌿",
      sound: "Peaceful moments",
      src: "https://www.w3schools.com/html/mov_bbb.mp4",
      likes: 8200,
      comments: [],
      liked: false,
      following: false,
      local: false
    }
  ];

  let posts = loadPosts();
  let profile = loadProfile();
  let activeFeed = "foryou";
  let activePage = "feedView";
  let toastTimer = null;

  function loadPosts() {
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey));
      return Array.isArray(saved) && saved.length ? saved : structuredClone(starterPosts);
    } catch {
      return structuredClone(starterPosts);
    }
  }

  function savePosts() {
    try {
      const safe = posts.map(post => ({ ...post, src: post.local ? "" : post.src }));
      localStorage.setItem(storageKey, JSON.stringify(safe));
    } catch {
      showToast("Storage is full. Try a smaller video.");
    }
  }

  function loadProfile() {
    try {
      return JSON.parse(localStorage.getItem(profileKey)) || {
        name: "TrendX Creator",
        handle: "trendx_creator",
        bio: "Create. Share. Inspire. ✨"
      };
    } catch {
      return { name: "TrendX Creator", handle: "trendx_creator", bio: "Create. Share. Inspire. ✨" };
    }
  }

  function saveProfile() {
    localStorage.setItem(profileKey, JSON.stringify(profile));
  }

  function showToast(message) {
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
  }

  function formatCount(value) {
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return String(value);
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[char]);
  }

  function visiblePosts() {
    if (activeFeed === "following") return posts.filter(post => post.following || post.username === profile.handle);
    if (activeFeed === "trending") return [...posts].sort((a, b) => b.likes - a.likes);
    return posts;
  }

  function renderFeed() {
    const feed = $("#videoFeed");
    const list = visiblePosts();
    if (!list.length) {
      feed.innerHTML = `<div class="empty-state"><div class="empty-icon">♡</div><h2>No videos yet</h2><p>Follow creators or upload your first video.</p></div>`;
      return;
    }

    feed.innerHTML = list.map(post => `
      <article class="video-card" data-post="${escapeHtml(post.id)}">
        <video class="video-media" src="${escapeHtml(post.src || "")}" ${post.src ? "loop" : ""} muted playsinline preload="metadata"></video>
        <div class="video-gradient"></div>
        <div class="video-copy">
          <div class="creator-line">
            <span class="creator-avatar">${escapeHtml((post.displayName || post.username).slice(0, 1).toUpperCase())}</span>
            <span>@${escapeHtml(post.username)}</span>
            ${post.username !== profile.handle ? `<button class="follow-chip" data-action="follow" data-id="${escapeHtml(post.id)}">Follow</button>` : ""}
          </div>
          <p class="video-caption">${escapeHtml(post.caption)}</p>
          <div class="video-sound">♫ ${escapeHtml(post.sound || "Original sound")}</div>
        </div>
        <div class="video-actions">
          <button class="action-button ${post.liked ? "liked" : ""}" data-action="like" data-id="${escapeHtml(post.id)}"><span>♥</span><small>${formatCount(post.likes)}</small></button>
          <button class="action-button" data-action="comment" data-id="${escapeHtml(post.id)}"><span>●</span><small>${formatCount(post.comments.length)} comments</small></button>
          <button class="action-button" data-action="share" data-id="${escapeHtml(post.id)}"><span>↗</span><small>Share</small></button>
          <button class="action-button" data-action="sound" data-id="${escapeHtml(post.id)}"><span>♫</span><small>Sound</small></button>
          <div class="action-avatar">${escapeHtml((post.username || "T").slice(0, 1).toUpperCase())}</div>
        </div>
        <div class="pause-indicator">▶</div>
      </article>`).join("");

    observeVideos();
  }

  let videoObserver;
  function observeVideos() {
    if (videoObserver) videoObserver.disconnect();
    videoObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        const video = $("video", entry.target);
        if (!video) return;
        if (entry.isIntersecting && entry.intersectionRatio > 0.65) {
          video.play().catch(() => {});
        } else {
          video.pause();
        }
      });
    }, { threshold: [0, 0.65, 1] });
    $$(".video-card").forEach(card => videoObserver.observe(card));
  }

  function switchPage(pageId) {
    activePage = pageId;
    ["feedView", "discoverView", "inboxView", "profileView"].forEach(id => {
      $(`#${id}`).classList.toggle("hidden", id !== pageId);
    });
    $$(".nav-item").forEach(button => button.classList.toggle("active", button.dataset.page === pageId));
    if (pageId === "profileView") renderProfile();
    if (pageId === "discoverView") renderDiscover();
  }

  function renderProfile() {
    $("#profileName").textContent = profile.name;
    $("#profileHandle").textContent = `@${profile.handle}`;
    $("#profileBio").textContent = profile.bio;
    $("#profileAvatar").textContent = profile.name.slice(0, 1).toUpperCase();
    const mine = posts.filter(post => post.username === profile.handle);
    $("#postCount").textContent = mine.length;
    $("#likeCount").textContent = formatCount(mine.reduce((sum, post) => sum + post.likes, 0));
    $("#profileGrid").innerHTML = mine.length ? mine.map(post => `
      <div class="profile-tile"><video src="${escapeHtml(post.src || "")}" muted playsinline></video><span>▶ ${formatCount(post.likes)}</span></div>
    `).join("") : `<div class="empty-state" style="grid-column:1/-1;padding:35px 10px"><p>Your videos will appear here.</p></div>`;
  }

  function renderDiscover(query = "") {
    const tags = ["#ForYou", "#TrendX", "#Pakistan", "#Comedy", "#Dance", "#Food", "#Nature", "#Gaming"];
    $("#tagCloud").innerHTML = tags.map(tag => `<button class="tag" data-tag="${tag}">${tag}</button>`).join("");
    const term = query.toLowerCase().replace("#", "");
    const results = posts.filter(post =>
      `${post.username} ${post.caption} ${post.displayName}`.toLowerCase().includes(term)
    );
    $("#discoverResults").innerHTML = results.map(post => `
      <div class="discover-card" data-open-post="${escapeHtml(post.id)}">
        <video src="${escapeHtml(post.src || "")}" muted playsinline></video>
        <span>▶ ${formatCount(post.likes)} · @${escapeHtml(post.username)}</span>
      </div>`).join("") || `<p class="empty-state">No matches found. Try another search.</p>`;
  }

  function openModal(title, content) {
    $("#modalTitle").textContent = title;
    $("#modalContent").innerHTML = content;
    $("#modalBackdrop").classList.add("open");
    $("#modalBackdrop").setAttribute("aria-hidden", "false");
  }

  function closeModal() {
    $("#modalBackdrop").classList.remove("open");
    $("#modalBackdrop").setAttribute("aria-hidden", "true");
  }

  function findPost(id) {
    return posts.find(post => post.id === id);
  }

  function toggleLike(id) {
    const post = findPost(id);
    if (!post) return;
    post.liked = !post.liked;
    post.likes = Math.max(0, post.likes + (post.liked ? 1 : -1));
    savePosts();
    renderFeed();
  }

  function openComments(id) {
    const post = findPost(id);
    if (!post) return;
    const comments = post.comments.map(comment => `
      <div class="comment"><b>@${escapeHtml(comment.user)}</b>${escapeHtml(comment.text)}</div>
    `).join("");
    openModal("Comments", `
      <div class="comment-list">${comments || `<p class="muted">Be the first to comment.</p>`}</div>
      <form id="commentForm">
        <textarea id="commentText" rows="2" maxlength="220" placeholder="Write a comment..." required></textarea>
        <button class="primary-button" type="submit">Post comment</button>
      </form>`);
    $("#commentForm").addEventListener("submit", event => {
      event.preventDefault();
      const text = $("#commentText").value.trim();
      if (!text) return;
      post.comments.push({ user: profile.handle, text });
      savePosts();
      closeModal();
      renderFeed();
      showToast("Comment added on this device.");
    });
  }

  async function sharePost(id) {
    const post = findPost(id);
    if (!post) return;
    const shareData = { title: "TrendX video", text: post.caption, url: location.href };
    try {
      if (navigator.share) await navigator.share(shareData);
      else if (navigator.clipboard) {
        await navigator.clipboard.writeText(`${post.caption} — ${location.href}`);
        showToast("Video caption copied.");
      } else showToast("Sharing is not supported on this browser.");
    } catch {
      // User cancelled the share sheet.
    }
  }

  function toggleFollow(id) {
    const post = findPost(id);
    if (!post) return;
    post.following = !post.following;
    savePosts();
    showToast(post.following ? `Following @${post.username}` : `Unfollowed @${post.username}`);
    renderFeed();
  }

  function openEditProfile() {
    openModal("Edit profile", `
      <form id="profileForm">
        <label>Display name<input id="nameInput" maxlength="30" value="${escapeHtml(profile.name)}" required></label>
        <label>Username<input id="handleInput" maxlength="24" value="${escapeHtml(profile.handle)}" required></label>
        <label>Bio<textarea id="bioInput" rows="3" maxlength="100">${escapeHtml(profile.bio)}</textarea></label>
        <button class="primary-button" type="submit">Save profile</button>
      </form>`);
    $("#profileForm").addEventListener("submit", event => {
      event.preventDefault();
      profile = {
        name: $("#nameInput").value.trim() || "TrendX Creator",
        handle: $("#handleInput").value.trim().replace(/^@/, "").replace(/[^a-zA-Z0-9_.]/g, "") || "trendx_creator",
        bio: $("#bioInput").value.trim()
      };
      saveProfile();
      closeModal();
      renderProfile();
      showToast("Profile updated on this device.");
    });
  }

  function startUpload() {
    $("#videoPicker").click();
  }

  function handleUpload(file) {
    if (!file) return;
    if (!file.type.startsWith("video/")) {
      showToast("Please choose a video file.");
      return;
    }
    if (file.size > 80 * 1024 * 1024) {
      showToast("For this demo, choose a video under 80 MB.");
      return;
    }
    const localUrl = URL.createObjectURL(file);
    const post = {
      id: `local-${Date.now()}`,
      username: profile.handle,
      displayName: profile.name,
      caption: "",
      sound: "Original sound",
      src: localUrl,
      likes: 0,
      comments: [],
      liked: false,
      following: true,
      local: true
    };
    openModal("Add a caption", `
      <video src="${localUrl}" controls playsinline style="width:100%;max-height:240px;border-radius:12px;background:#000"></video>
      <textarea id="captionInput" rows="3" maxlength="180" placeholder="Write a caption and add hashtags..."></textarea>
      <button class="primary-button" id="publishVideo">Publish video</button>
      <p class="muted">This prototype keeps the selected video in this browser session. It is not uploaded to a public server.</p>`);
    $("#publishVideo").addEventListener("click", () => {
      post.caption = $("#captionInput").value.trim() || "New video on TrendX ✨";
      posts.unshift(post);
      savePosts();
      closeModal();
      activeFeed = "foryou";
      $$(".feed-tab").forEach(tab => tab.classList.toggle("active", tab.dataset.feed === activeFeed));
      switchPage("feedView");
      renderFeed();
      showToast("Video added to your local feed.");
    });
  }

  function openSearch() {
    switchPage("discoverView");
    $("#discoverSearch").focus();
  }

  document.addEventListener("click", event => {
    const action = event.target.closest("[data-action]");
    if (action) {
      const { action: type, id } = action.dataset;
      if (type === "like") toggleLike(id);
      if (type === "comment") openComments(id);
      if (type === "share") sharePost(id);
      if (type === "follow") toggleFollow(id);
      if (type === "sound") showToast("Sound controls can be added with a media backend.");
      return;
    }
    const pageButton = event.target.closest("[data-page]");
    if (pageButton) switchPage(pageButton.dataset.page);
    const feedButton = event.target.closest("[data-feed]");
    if (feedButton) {
      activeFeed = feedButton.dataset.feed;
      $$(".feed-tab").forEach(tab => tab.classList.toggle("active", tab === feedButton));
      renderFeed();
    }
    const tagButton = event.target.closest("[data-tag]");
    if (tagButton) {
      $("#discoverSearch").value = tagButton.dataset.tag;
      renderDiscover(tagButton.dataset.tag);
    }
    const card = event.target.closest(".video-card");
    if (card && !event.target.closest("button")) {
      const video = $("video", card);
      if (video.paused) {
        video.play().catch(() => {});
        card.classList.remove("paused");
      } else {
        video.pause();
        card.classList.add("paused");
      }
    }
  });

  $("#createVideo").addEventListener("click", startUpload);
  $("#videoPicker").addEventListener("change", event => handleUpload(event.target.files[0]));
  $("#openSearch").addEventListener("click", openSearch);
  $("#discoverSearch").addEventListener("input", event => renderDiscover(event.target.value));
  $("#editProfile").addEventListener("click", openEditProfile);
  $("#modalClose").addEventListener("click", closeModal);
  $("#modalBackdrop").addEventListener("click", event => {
    if (event.target.id === "modalBackdrop") closeModal();
  });

  renderFeed();
  renderProfile();
})();
