# TrendX brand identity

The app uses an original geometric TrendX mark and a readable TrendX wordmark.
It does not use TikTok's musical-note logo or copy its logo silhouette.
Brand palette: midnight black, electric cyan, violet and coral pink.
Primary logo: `assets/trendx-logo.svg`
App icon: `assets/icon.svg`
