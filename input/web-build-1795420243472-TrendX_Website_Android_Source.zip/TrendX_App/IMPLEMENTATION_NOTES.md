# TrendX implementation notes

This document records the next engineering milestones for turning the prototype into a production social-video service.

## Accounts and identity
- Add email/password or phone authentication.
- Verify accounts before enabling public uploads.
- Store usernames in a unique database index.
- Add account recovery and session revocation.
- Add profile image upload with file validation.
- Add privacy controls for public and private profiles.
- Add account deletion and data export.
- Add age-appropriate safety and reporting flows.

## Video infrastructure
- Upload original videos to private object storage.
- Validate file size, MIME type and actual media format server-side.
- Transcode uploads into adaptive streaming formats.
- Generate thumbnails and preview clips.
- Use a CDN for delivery.
- Keep storage paths separate from user-controlled filenames.
- Scan uploads and reject unsupported or harmful content.
- Add upload progress and retry handling.
- Add deletion and retention policies.
- Never trust client-provided like counts or creator IDs.

## Feed and discovery
- Create a server-side feed endpoint.
- Rank videos using freshness, quality and user-selected interests.
- Add pagination and cursor-based loading.
- Record views with deduplication and abuse controls.
- Add hashtag and creator indexes.
- Add content preference controls.
- Provide a chronological feed option.
- Avoid exposing private or blocked creator content.

## Community safety
- Add report-video, report-comment and block-user actions.
- Build a moderation queue for reported content.
- Add rate limits for comments, follows and uploads.
- Add spam and impersonation detection.
- Provide clear community guidelines.
- Maintain an audit log for moderator actions.
- Add appeals and account support processes.

## Reliability and security
- Use HTTPS everywhere.
- Keep secrets on the server.
- Apply database security rules and least-privilege access.
- Validate every request on the backend.
- Add backups and restore testing.
- Monitor upload failures and API errors.
- Add privacy policy and terms before public launch.
- Test accessibility, low-bandwidth use and smaller Android screens.

## Release checklist
- Test on current Chrome for Android.
- Test install prompt and offline app shell.
- Test upload permissions and rejected file types.
- Test playback on slow networks.
- Test keyboard and screen-reader navigation.
- Create signed release keys securely.
- Prepare Play Store screenshots and privacy declarations.
- Complete policy review before publishing.
