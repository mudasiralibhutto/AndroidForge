# MC6 — MUDASIR CITY 6
An early browser-playable 3D open-world prototype with a procedural tropical city, third-person character, vehicles, enter/exit interaction, keyboard controls and mobile touch buttons.

## Run
1. Extract the ZIP.
2. Open the folder in a local web server (recommended) or upload it to a static hosting service.
3. Open `index.html` in a modern browser with internet access. Three.js is loaded from jsDelivr CDN.
4. On Android, use the on-screen direction pad and RUN / ENTER CAR buttons.

## Controls
- WASD / Arrow keys: move
- Shift: run
- E: enter or exit a nearby car
- Mobile: on-screen buttons

## Important
This is a prototype, not a finished commercial game or native APK. It uses procedural placeholder 3D assets and requires internet access for the Three.js CDN. A true GTA-scale game needs a full game engine, original 3D models, animation, audio, optimization, testing and a native Android build pipeline.
