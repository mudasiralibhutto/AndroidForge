import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf5a18b);
scene.fog = new THREE.Fog(0xf5a18b, 90, 420);
const camera = new THREE.PerspectiveCamera(68, innerWidth/innerHeight, .1, 900);
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(innerWidth,innerHeight); renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));
renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.15;
document.body.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xb9d9ff,0x70464a,2.0));
const sun=new THREE.DirectionalLight(0xffd0a0,3.2); sun.position.set(-80,130,65); sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048); sun.shadow.camera.left=-150;sun.shadow.camera.right=150;sun.shadow.camera.top=150;sun.shadow.camera.bottom=-150;scene.add(sun);

const mat=(color,rough=.8,metal=0)=>new THREE.MeshStandardMaterial({color,roughness:rough,metalness:metal});
const asphalt=mat(0x343a48), sidewalk=mat(0xb9a9a0), sand=mat(0xe4c39b), grass=mat(0x547b55), white=mat(0xf1e9dc), glass=new THREE.MeshStandardMaterial({color:0x83b7ce,roughness:.18,metalness:.45});
const world=new THREE.Group();scene.add(world);
function box(parent,w,h,d,material,x,y,z){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
function ground(w,d,material,x,z){const m=new THREE.Mesh(new THREE.PlaneGeometry(w,d),material);m.rotation.x=-Math.PI/2;m.position.set(x,0,z);m.receiveShadow=true;world.add(m);return m}
ground(700,700,grass,0,0);
ground(700,90,sand,0,-155);
ground(700,34,asphalt,0,-95);
ground(700,34,asphalt,0,0);
ground(700,34,asphalt,0,95);
ground(34,700,asphalt,-120,0);ground(34,700,asphalt,120,0);
for(let z=-320;z<=320;z+=95){box(world,700,.12,2,mat(0xe8d8a9),0,.07,z-17)}
for(let x=-320;x<=320;x+=95){box(world,2,.12,700,mat(0xe8d8a9),x,.07,0)}
// Beach and ocean
const ocean=new THREE.Mesh(new THREE.PlaneGeometry(700,260),new THREE.MeshStandardMaterial({color:0x238da9,roughness:.28,metalness:.18}));ocean.rotation.x=-Math.PI/2;ocean.position.set(0,-.4,-300);world.add(ocean);
// City blocks with varied heights, lit windows and storefront colors
const buildingMats=[0xeee1d2,0xd3c8bf,0x9fb2c2,0xe2b9a5,0x8c9ba9,0xd8d4cb].map(c=>mat(c,.75));
for(let x=-300;x<=300;x+=42){for(let z=-285;z<=245;z+=46){
 if(Math.abs(z+95)<30||Math.abs(z)<30||Math.abs(z-95)<30||Math.abs(x+120)<30||Math.abs(x-120)<30)continue;
 const h=12+Math.random()*48,w=20+Math.random()*12,d=20+Math.random()*12;
 const b=box(world,w,h,d,buildingMats[Math.floor(Math.random()*buildingMats.length)],x,h/2,z);
 box(world,w+.5,.7,d+.5,mat(0x4b5366),x,h+.35,z);
 const rows=Math.floor(h/4);
 for(let yy=3;yy<h-2;yy+=4){for(let xx=-w/2+2;xx<w/2-1;xx+=4){
 const win=new THREE.Mesh(new THREE.PlaneGeometry(1.7,2.1),mat(Math.random()>.35?0x7cc9e7:0xffd28a,.35,.2));
 win.position.set(x+xx,yy,z+d/2+.03);world.add(win);
 }}
}}
function palm(x,z,scale=1){const g=new THREE.Group();g.position.set(x,0,z);g.scale.setScalar(scale);world.add(g);
 const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.35,.6,9,8),mat(0x79563d));trunk.position.y=4.5;trunk.rotation.z=.08;trunk.castShadow=true;g.add(trunk);
 for(let i=0;i<8;i++){const a=i*Math.PI/4;const leaf=new THREE.Mesh(new THREE.ConeGeometry(.55,8,5),mat(0x23744d));leaf.position.set(Math.cos(a)*2.8,8.5+Math.sin(a)*.5,Math.sin(a)*2.8);leaf.rotation.z=-Math.cos(a)*.9;leaf.rotation.x=Math.sin(a)*.9;g.add(leaf)}
}
for(let x=-320;x<=320;x+=28){palm(x,-125,.8);palm(x,-65,.7);if(x%56===0)palm(x,28,.8)}
// Ferris wheel landmark
const wheel=new THREE.Group();wheel.position.set(-65,24,-145);world.add(wheel);
const ring=new THREE.Mesh(new THREE.TorusGeometry(19,.55,8,64),mat(0xe6d9d5,.35,.6));wheel.add(ring);
for(let i=0;i<12;i++){const a=i*Math.PI/6;const spoke=box(wheel,.28,38,.28,mat(0xf5d7bc),Math.cos(a)*9.5,Math.sin(a)*9.5,0);spoke.rotation.z=a}
box(world,3,15,3,mat(0x68616a),-65,7.5,-145);box(world,3,15,3,mat(0x68616a),-65,7.5,-145);
// Player
const player=new THREE.Group();world.add(player);
const skin=mat(0xc88c69), shirt=mat(0x6e263c), pants=mat(0x252a35), dark=mat(0x161923);
const torso=box(player,1.05,1.35,.55,shirt,0,1.55,0);const head=new THREE.Mesh(new THREE.SphereGeometry(.34,18,14),skin);head.position.y=2.48;head.castShadow=true;player.add(head);
const cap=box(player,.76,.18,.7,mat(0x244d9a),0,2.78,0);cap.rotation.x=.04;
const legL=box(player,.36,1,.4,pants,-.27,.5,0),legR=box(player,.36,1,.4,pants,.27,.5,0);
const armL=box(player,.28,1,.3,shirt,-.68,1.62,0),armR=box(player,.28,1,.3,shirt,.68,1.62,0);
player.position.set(0,0,35);
// Vehicles
const vehicles=[];
function makeCar(x,z,color=0x8c1f65){const g=new THREE.Group();world.add(g);g.position.set(x,0,z);
 box(g,2.2,.65,4.4,mat(color,.35,.55),0,.72,0);box(g,1.8,.72,2.1,glass,0,1.35,-.15);
 for(const sx of [-1,1])for(const sz of [-1,1]){const w=new THREE.Mesh(new THREE.CylinderGeometry(.42,.42,.25,16),dark);w.rotation.z=Math.PI/2;w.position.set(sx*1.12,.42,sz*1.35);g.add(w)}
 box(g,.6,.18,.08,mat(0xffe8b0),-.65,.75,2.22);box(g,.6,.18,.08,mat(0xffe8b0),.65,.75,2.22);
 const v={group:g,speed:0,occupied:false};vehicles.push(v);return v}
makeCar(-14,35,0x8b1d6a);makeCar(12,-35,0xd5d9df);makeCar(18,72,0x20232c);makeCar(-35,-15,0xb93a28);makeCar(65,-95,0x1d6a9b);
let activeCar=null;
// Street lights
for(let x=-300;x<=300;x+=42){for(const z of [-112,-17,78]){const pole=box(world,.18,7,.18,mat(0x3a414d),x,3.5,z);box(world,2,.15,.2,mat(0xffe4a0),x+1,7,z)}}
const keys={};addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.key.toLowerCase()==='e')interact()});addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
let touch={};document.querySelectorAll('[data-key]').forEach(b=>{const k=b.dataset.key;b.addEventListener('pointerdown',e=>{e.preventDefault();touch[k]=true});['pointerup','pointerleave','pointercancel'].forEach(ev=>b.addEventListener(ev,()=>touch[k]=false))});
document.getElementById('run').addEventListener('pointerdown',()=>touch.shift=true);document.getElementById('run').addEventListener('pointerup',()=>touch.shift=false);
document.getElementById('interact').addEventListener('click',interact);
function notify(t){const el=document.getElementById('toast');el.textContent=t;setTimeout(()=>{if(el.textContent===t)el.textContent=''},1800)}
function interact(){if(activeCar){activeCar.occupied=false;player.visible=true;player.position.copy(activeCar.group.position);player.position.x+=2.5;activeCar=null;document.getElementById('interact').textContent='ENTER CAR';notify('You left the vehicle');return}
 let nearest=null,dist=6;for(const v of vehicles){const d=v.group.position.distanceTo(player.position);if(d<dist){dist=d;nearest=v}}
 if(nearest){activeCar=nearest;nearest.occupied=true;player.visible=false;document.getElementById('interact').textContent='EXIT CAR';notify('Vehicle entered — drive!')}else notify('Move closer to a car')}
function movePlayer(dt){let f=(keys.w||keys.arrowup||touch.w?1:0)-(keys.s||keys.arrowdown||touch.s?1:0),r=(keys.d||keys.arrowright||touch.d?1:0)-(keys.a||keys.arrowleft||touch.a?1:0);
 const running=keys.shift||touch.shift;const speed=running?13:7;
 if(activeCar){activeCar.speed+=(f*22-activeCar.speed*2.8)*dt;activeCar.group.rotation.y-=r*dt*1.6;const dir=new THREE.Vector3(Math.sin(activeCar.group.rotation.y),0,Math.cos(activeCar.group.rotation.y));activeCar.group.position.addScaledVector(dir,activeCar.speed*dt);activeCar.group.position.x=THREE.MathUtils.clamp(activeCar.group.position.x,-330,330);activeCar.group.position.z=THREE.MathUtils.clamp(activeCar.group.position.z,-330,330);return}
 if(f||r){const v=new THREE.Vector3(r,0,-f).normalize();player.position.addScaledVector(v,speed*dt);player.rotation.y=Math.atan2(v.x,v.z)}
 player.position.x=THREE.MathUtils.clamp(player.position.x,-330,330);player.position.z=THREE.MathUtils.clamp(player.position.z,-330,330);
}
let last=performance.now(),elapsed=0;
function animate(now){requestAnimationFrame(animate);const dt=Math.min((now-last)/1000,.04);last=now;elapsed+=dt;movePlayer(dt);
 const target=activeCar?activeCar.group.position:player.position;
 const desired=new THREE.Vector3(target.x+Math.sin((activeCar?activeCar.group.rotation.y:player.rotation.y)+Math.PI)*8,6.2,target.z+Math.cos((activeCar?activeCar.group.rotation.y:player.rotation.y)+Math.PI)*8);
 camera.position.lerp(desired,.09);camera.lookAt(target.x,1.5,target.z);
 wheel.rotation.z=Math.sin(elapsed*.18)*.08;
 for(const v of vehicles){if(v!==activeCar&&!v.occupied){v.group.position.x+=Math.sin(elapsed*.15+v.group.position.z)*dt*.7}}
 const mins=Math.floor(elapsed/60),secs=Math.floor(elapsed%60);document.getElementById('clock').textContent=`18:${String((45+mins)%60).padStart(2,'0')}`;
 renderer.render(scene,camera)}
requestAnimationFrame(animate);
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
document.getElementById('loading').style.display='none';
