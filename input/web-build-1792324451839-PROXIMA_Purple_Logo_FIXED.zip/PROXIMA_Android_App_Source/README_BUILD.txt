PROXIMA Digital Wallet — Android source project

This ZIP is source code, not a compiled APK. It contains a custom PROXIMA P launcher icon and an interactive on-device prototype. Demo OTP: 123456. Sample balance and simulated transfers are stored locally on the device.

Build APK: open this project in Android Studio, allow Gradle sync, then Build > Build APK(s). On mobile, AndroidForge may build it if its GitHub API/workflow setup succeeds.

IMPORTANT: This is NOT a licensed bank and cannot move real money. To launch real-money features you must establish a legal business and work with a licensed bank/payment service provider in Pakistan, complete their onboarding/KYC and regulatory requirements, obtain API credentials, and deploy a secure server-side backend. Never store payment secrets in this app or send GitHub tokens in chat. Real SMS OTP also requires an SMS provider.


DESIGN UPDATE (2026-10-18): Refreshed wallet dashboard styling with premium green balance panel, quick actions, promotional banner, three card tiers (Golden, Platinum, Silver), and improved profile/settings. This remains a local demo prototype; no real funds, banking rails, SMS OTP, or issued cards are connected.
