package com.proxima.wallet;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(Color.rgb(8,13,11));
    getWindow().setNavigationBarColor(Color.rgb(8,13,11));
    WebView web = new WebView(this);
    web.setBackgroundColor(Color.rgb(8,13,11));
    web.setWebViewClient(new WebViewClient());
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
}
