PROXIMA Digital Wallet — Android source project

This is source code, not a compiled APK. It includes a custom PROXIMA launcher icon (green P) and a WebView-based demo wallet screen.

To build: open this project in Android Studio, allow Gradle sync, then Build > Build APK(s).

Important: This is a UI demo only. It is not a licensed bank and does not move real money, process bills/mobile loads, or issue payment cards. Do not use real financial credentials.
