# PROXIMA Android Demo Wallet V2

A native Android Studio starter project with a premium black/emerald wallet UI.

## V2 demo features
- Demo balance changes when a transfer is made
- Demo send-money form with receiver name, demo wallet ID, amount and a 4-digit demo PIN
- Insufficient-balance and validation checks
- Generated demo transaction ID and timestamp
- Success/failure confirmation tones using Android ToneGenerator
- Success screen with a clearly labelled DEMO receipt
- PDF demo receipt saved to Downloads/PROXIMA
- Home dashboard, demo activity, preview cards and profile

## Critical limitation
This is a local demonstration only. It does not create a real account, authenticate a real user,
credit another real user's wallet, connect to a bank/EMI, or move real money. A successful
transfer only updates the sample balance in this app's running session. The receiver wallet ID
is receipt metadata, not a live destination. The receipt is prominently labelled DEMO.

## Real-money readiness
Before real-money functions can be activated, PROXIMA needs a formal relationship with an
SBP-authorized bank or EMI, partner-approved APIs and credentials, server-side ledger and
idempotent transaction processing, KYC/AML and sanctions controls, reconciliation, fraud
monitoring, security testing, privacy controls and legal/compliance approval. Never store
provider secrets, OTP secrets, card data or PINs in the Android app.

## Build
1. Extract the ZIP.
2. Open the `PROXIMA_Android_Starter` folder in Android Studio.
3. Use JDK 17 and allow Gradle sync.
4. Run on an Android device or emulator (Android 7.0 / API 24 or newer).
5. Build > Build Bundle(s) / APK(s) > Build APK(s).

This ZIP contains source code, not a precompiled APK.
