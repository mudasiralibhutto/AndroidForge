package com.proxima.wallet

import android.content.ContentValues
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Ink = Color(0xFF07110D)
private val Panel = Color(0xFF12221A)
private val Green = Color(0xFFB7F56A)
private val Muted = Color(0xFF9EADA2)
private val White = Color(0xFFF5F8F4)

data class DemoTxn(
    val receiver: String, val wallet: String, val amount: Double,
    val id: String, val date: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ProximaApp(
            onSound = { success ->
                val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
                tone.startTone(if (success) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK, 220)
                android.os.Handler(mainLooper).postDelayed({ tone.release() }, 350)
            },
            onReceipt = { txn -> createReceiptPdf(txn) }
        ) }
    }

    private fun createReceiptPdf(txn: DemoTxn) {
        try {
            val pdf = PdfDocument()
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
            val canvas = page.canvas
            val title = Paint().apply { color = android.graphics.Color.rgb(20, 65, 39); textSize = 30f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
            val heading = Paint().apply { color = android.graphics.Color.DKGRAY; textSize = 17f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
            val body = Paint().apply { color = android.graphics.Color.DKGRAY; textSize = 15f }
            val green = Paint().apply { color = android.graphics.Color.rgb(35, 125, 65); textSize = 18f; typeface = Typeface.DEFAULT_BOLD }
            canvas.drawText("PROXIMA", 48f, 72f, title)
            canvas.drawText("DIGITAL WALLET • DEMO RECEIPT", 48f, 105f, body)
            canvas.drawLine(48f, 130f, 547f, 130f, body)
            canvas.drawText("TRANSFER SUCCESSFUL (DEMO)", 48f, 180f, green)
            canvas.drawText("Rs. ${"%,.2f".format(Locale.US, txn.amount)}", 48f, 235f, title)
            var y = 300f
            fun row(label: String, value: String) {
                canvas.drawText(label, 48f, y, heading)
                canvas.drawText(value.take(48), 245f, y, body)
                y += 48f
            }
            row("Receiver", txn.receiver)
            row("Wallet ID", txn.wallet)
            row("Date & time", txn.date)
            row("Transaction ID", txn.id)
            canvas.drawLine(48f, y + 8f, 547f, y + 8f, body)
            canvas.drawText("SIMULATED TRANSACTION — NO REAL MONEY MOVED", 48f, y + 55f, green)
            canvas.drawText("This receipt is for PROXIMA demo testing only.", 48f, y + 88f, body)
            pdf.finishPage(page)

            val filename = "PROXIMA_DEMO_${txn.id}.pdf"
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PROXIMA")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) }
            pdf.close()
            Toast.makeText(this, if (uri != null) "Demo receipt saved in Downloads/PROXIMA" else "Could not save receipt", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Receipt error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}

@Composable
fun ProximaApp(onSound: (Boolean) -> Unit, onReceipt: (DemoTxn) -> Unit) {
    var selected by remember { mutableStateOf("Home") }
    var balance by remember { mutableDoubleStateOf(125400.0) }
    var transactions by remember { mutableStateOf(listOf<DemoTxn>()) }
    var latestReceipt by remember { mutableStateOf<DemoTxn?>(null) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Green,
        onPrimary = Ink, onBackground = White, onSurface = White
    )) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Green) {
                listOf("Home", "Send", "Cards", "Activity", "Profile").forEach { item ->
                    val icon = when(item) {
                        "Home" -> Icons.Default.Home
                        "Send" -> Icons.Default.Send
                        "Cards" -> Icons.Default.CreditCard
                        "Activity" -> Icons.Default.ReceiptLong
                        else -> Icons.Default.Person
                    }
                    NavigationBarItem(selected = selected == item, onClick = { selected = item },
                        icon = { Icon(icon, contentDescription = item) }, label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Green,
                            selectedTextColor = Green, indicatorColor = Color(0xFF29402E),
                            unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            when(selected) {
                "Home" -> HomeScreen(Modifier.padding(padding), balance, transactions, { selected = "Send" })
                "Send" -> SendScreen(Modifier.padding(padding), balance, onSound,
                    { txn -> balance -= txn.amount; transactions = listOf(txn) + transactions; latestReceipt = txn; selected = "Receipt" })
                "Cards" -> CardsScreen(Modifier.padding(padding))
                "Activity" -> ActivityScreen(Modifier.padding(padding), transactions)
                "Receipt" -> ReceiptScreen(Modifier.padding(padding), latestReceipt, onReceipt, { selected = "Home" }, onSound)
                else -> ProfileScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier, balance: Double, txns: List<DemoTxn>, goSend: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 22.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("PROXIMA", color = Green, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text("DIGITAL WALLET", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp) }
                Box(Modifier.size(44.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.NotificationsNone, null, tint = White) }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF25452F), Color(0xFF102019))), RoundedCornerShape(24.dp)).padding(22.dp)) {
                Text("TOTAL WALLET BALANCE", color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
                Spacer(Modifier.height(12.dp))
                Text("Rs. ${"%,.2f".format(Locale.US, balance)}", color = White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("DEMO PREVIEW • NOT REAL MONEY", color = Green, fontSize = 10.sp, letterSpacing = 1.sp)
            }
        }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            QuickAction("Send", Icons.Default.NorthEast, goSend)
            QuickAction("Receive", Icons.Default.SouthWest) {}
            QuickAction("Bills", Icons.Default.Receipt) {}
            QuickAction("Load", Icons.Default.PhoneAndroid) {}
        } }
        item { SectionTitle("Your cards", "PREVIEW") }
        item { BankCard("PROXIMA PLATINUM", "••••  ••••  ••••  4528", Color(0xFF263A32)) }
        item { SectionTitle("Recent activity", "DEMO") }
        if (txns.isEmpty()) item { Text("No demo transfers yet. Try sending a test payment.", color = Muted, fontSize = 12.sp) }
        items(txns.size) { index -> val t = txns[index]; ActivityRow("Transfer to ${t.receiver}", t.date, "− Rs. ${"%,.2f".format(Locale.US, t.amount)}", false) }
    }
}

@Composable
fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, click: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(72.dp).clickable { click() }) {
        Box(Modifier.size(54.dp).background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Green) }
        Spacer(Modifier.height(7.dp)); Text(label, color = White, fontSize = 12.sp)
    }
}
@Composable fun SectionTitle(title: String, action: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(action, color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}
@Composable fun BankCard(title: String, number: String, color: Color) {
    Column(Modifier.fillMaxWidth().background(color, RoundedCornerShape(20.dp)).padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("PROXIMA", color = Green, fontWeight = FontWeight.Black, letterSpacing = 2.sp); Icon(Icons.Default.Contactless, null, tint = White) }
        Spacer(Modifier.height(28.dp)); Text(number, color = White, fontSize = 18.sp, letterSpacing = 2.sp); Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("CARDHOLDER", color = Muted, fontSize = 9.sp); Text(title, color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
    }
}
@Composable fun ActivityRow(title: String, subtitle: String, amount: String, positive: Boolean) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).background(Color(0xFF263A2E), CircleShape), contentAlignment = Alignment.Center) { Icon(if(positive) Icons.Default.ArrowDownward else Icons.Default.Send, null, tint = Green) }
        Column(Modifier.weight(1f).padding(start=12.dp)) { Text(title, color=White, fontWeight=FontWeight.SemiBold, fontSize=13.sp); Text(subtitle, color=Muted, fontSize=10.sp) }
        Text(amount, color=if(positive) Green else White, fontWeight=FontWeight.Bold, fontSize=12.sp)
    }
}

@Composable
fun SendScreen(modifier: Modifier, balance: Double, onSound: (Boolean) -> Unit, onSuccess: (DemoTxn) -> Unit) {
    var receiver by remember { mutableStateOf("") }
    var wallet by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        ScreenHeading("Send money", "PROXIMA-to-PROXIMA demo transfer")
        Text("Available demo balance: Rs. ${"%,.2f".format(Locale.US, balance)}", color=Green, fontSize=13.sp)
        OutlinedTextField(receiver, { receiver = it }, label={ Text("Receiver full name") }, modifier=Modifier.fillMaxWidth(), singleLine=true)
        OutlinedTextField(wallet, { wallet = it }, label={ Text("Receiver demo wallet ID") }, modifier=Modifier.fillMaxWidth(), singleLine=true)
        OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' } }, label={ Text("Amount (PKR)") }, modifier=Modifier.fillMaxWidth(), singleLine=true, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(4) }, label={ Text("4-digit demo PIN (any 4 digits)") }, modifier=Modifier.fillMaxWidth(), singleLine=true, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword))
        Text("Demo only: this does not contact banks or move real money.", color=Muted, fontSize=11.sp)
        if(error.isNotBlank()) Text(error, color=Color(0xFFFF8A80), fontSize=12.sp)
        Button(onClick = {
            val value = amount.toDoubleOrNull()
            if(receiver.isBlank() || wallet.isBlank() || value == null || value <= 0 || pin.length != 4) {
                error = "Enter receiver, wallet ID, valid amount and 4-digit demo PIN."
                onSound(false)
            } else if(value > balance) {
                error = "Insufficient demo balance."
                onSound(false)
            } else {
                error = ""
                val date = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                val txn = DemoTxn(receiver.trim(), wallet.trim(), value, "PRX-" + UUID.randomUUID().toString().take(8).uppercase(), date)
                onSound(true); onSuccess(txn)
            }
        }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Green, contentColor=Ink)) {
            Icon(Icons.Default.Lock, null); Spacer(Modifier.width(8.dp)); Text("CONFIRM DEMO TRANSFER", fontWeight=FontWeight.Bold)
        }
    }
}

@Composable
fun ReceiptScreen(modifier: Modifier, txn: DemoTxn?, onReceipt: (DemoTxn) -> Unit, back: () -> Unit, onSound: (Boolean) -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement=Arrangement.spacedBy(16.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Spacer(Modifier.height(18.dp))
        Box(Modifier.size(72.dp).background(Color(0xFF24452D), CircleShape), contentAlignment=Alignment.Center) { Icon(Icons.Default.Check, null, tint=Green, modifier=Modifier.size(42.dp)) }
        Text("Transfer successful", color=White, fontSize=24.sp, fontWeight=FontWeight.Bold)
        Text("DEMO TRANSACTION • NO REAL MONEY", color=Green, fontSize=11.sp)
        if(txn != null) {
            Text("Rs. ${"%,.2f".format(Locale.US, txn.amount)}", color=White, fontSize=32.sp, fontWeight=FontWeight.Bold)
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                ReceiptLine("Receiver", txn.receiver); ReceiptLine("Wallet ID", txn.wallet); ReceiptLine("Date & time", txn.date); ReceiptLine("Transaction ID", txn.id); ReceiptLine("Status", "SUCCESSFUL • DEMO")
            }
            Button(onClick = { onReceipt(txn); onSound(true) }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Green, contentColor=Ink)) {
                Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text("SAVE PDF RECEIPT")
            }
        }
        OutlinedButton(onClick=back, modifier=Modifier.fillMaxWidth()) { Text("BACK TO HOME") }
    }
}
@Composable fun ReceiptLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
        Text(label, color=Muted, fontSize=12.sp); Text(value, color=White, fontSize=12.sp, fontWeight=FontWeight.SemiBold)
    }
}
@Composable fun CardsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement=Arrangement.spacedBy(18.dp)) {
        ScreenHeading("Your cards", "Choose your PROXIMA card")
        BankCard("PLATINUM", "••••  ••••  ••••  4528", Color(0xFF263A32))
        BankCard("GOLD", "••••  ••••  ••••  1186", Color(0xFF514323))
        BankCard("SILVER", "••••  ••••  ••••  9031", Color(0xFF3C4548))
        Text("Preview cards only. No payment credentials are active.", color=Muted, fontSize=11.sp)
    }
}
@Composable fun ActivityScreen(modifier: Modifier = Modifier, txns: List<DemoTxn>) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
        ScreenHeading("Activity", "Your demo transaction history")
        if(txns.isEmpty()) Text("No transactions yet.", color=Muted)
        txns.forEach { ActivityRow("Transfer to ${it.receiver}", it.date, "− Rs. ${"%,.2f".format(Locale.US, it.amount)}", false) }
    }
}
@Composable fun ProfileScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
        ScreenHeading("Profile", "Account and security")
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(18.dp), verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).background(Color(0xFF29402E), CircleShape), contentAlignment=Alignment.Center) { Icon(Icons.Default.Person, null, tint=Green) }
            Column(Modifier.padding(start=14.dp)) { Text("PROXIMA USER", color=White, fontWeight=FontWeight.Bold); Text("Preview profile", color=Muted, fontSize=12.sp) }
        }
        listOf("Personal information", "Identity verification", "Security & PIN", "Notifications", "Help & support").forEach {
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { }.padding(16.dp), horizontalArrangement=Arrangement.SpaceBetween) {
                Text(it, color=White, fontSize=14.sp); Icon(Icons.Default.ChevronRight, null, tint=Muted)
            }
        }
    }
}
@Composable fun ScreenHeading(title: String, subtitle: String) {
    Column(Modifier.padding(top=22.dp, bottom=8.dp)) { Text(title, color=White, fontSize=26.sp, fontWeight=FontWeight.Bold); Text(subtitle, color=Muted, fontSize=13.sp) }
}
