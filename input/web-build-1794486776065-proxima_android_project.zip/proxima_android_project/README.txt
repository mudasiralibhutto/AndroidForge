PROXIMA DIGITAL BANK - Android demo project

This is a WebView Android Studio project containing the Proxima HTML demo.
It is NOT a compiled APK. To build:
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be in app/build/outputs/apk/debug/app-debug.apk

Important: This is a visual/demo app only. It does not connect to a bank and cannot move real money.
Real-money services require a properly licensed banking/payment partner, security controls, and regulatory approvals.
